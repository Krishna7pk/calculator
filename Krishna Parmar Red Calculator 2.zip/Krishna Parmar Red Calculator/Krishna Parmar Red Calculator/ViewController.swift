//
//  ViewController.swift
//  Krishna Parmar Red Calculator
//
//  Created by Karan on 2022-02-11.
// To add constraint use =  control and click drag
//to copy =option and click drag
//to add buttonclick = control and click drag


import UIKit

class ViewController: UIViewController {
    
//MARK:-Outlets
    //1 step
    
  
    
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn5: UIButton!
    
    @IBOutlet weak var btn6: UIButton!
    
    @IBOutlet weak var btn7: UIButton!
    
    
    @IBOutlet weak var btn8: UIButton!
    
    @IBOutlet weak var btn9: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
//Mark:-Actions
    //second step connect to the button using right click
    
    @IBAction func onClicked(_ sender: UIButton) {
       
        let buttonText = sender.titleLabel?.text
        var myNumber = (buttonText! as NSString) .integerValue
        
        if(myNumber>5){
            
            myNumber = myNumber - 1
            let numberStr = "\(myNumber)"
            sender.setTitle(numberStr, for: .normal)
           
        }
        else if(myNumber<5)
        {
            myNumber = myNumber + 1
            let numberStr = "\(myNumber)"
            sender.setTitle(numberStr, for: .normal)
        }
        else{
            print(myNumber)
            
        }
        

    }
    @IBAction func resetButton(_ sender: UIButton) {
        btn1.setTitle("2", for: .normal)
        btn2.setTitle("0", for: .normal)
        btn3.setTitle("0", for: .normal)
        btn4.setTitle("5", for: .normal)
        btn5.setTitle("0", for: .normal)
        btn6.setTitle("4", for: .normal)
        btn7.setTitle("9", for: .normal)
        btn8.setTitle("8", for: .normal)
        btn9.setTitle("1", for: .normal)
        
    }
}

