//
//  ViewController.swift
//  Krishna_Parmar_NumbersGame
//
//  Created by Karan on 2022-02-12.
//

import UIKit

class ViewController: UIViewController {
    //Outlets of button
    @IBOutlet weak var buttonVal2: UIButton!
    @IBOutlet weak var buttonVal0: UIButton!
    @IBOutlet weak var buttonVal0_0: UIButton!
    @IBOutlet weak var buttonVal5: UIButton!
    @IBOutlet weak var buttonVal00_0: UIButton!
    @IBOutlet weak var buttonVal4: UIButton!
    @IBOutlet weak var buttonVal9: UIButton!
    @IBOutlet weak var buttonVal8: UIButton!
    @IBOutlet weak var buttonVal1: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        print("button is clicked")
        let buttonText = sender.titleLabel?.text
        var currentText = (buttonText! as NSString) .integerValue
               
        if(currentText>1){
            //student id = 200504981
            //last digit is 1, decrement by1 if its greater than 1
            currentText = currentText - 1
                   let numberStr = "\(currentText)"
                   sender.setTitle(numberStr, for: .normal)
                  
               }
               else if(currentText<1)
               {
                   //last digit is 1, increment by1 if its less than 1
                   currentText = currentText + 1
                   let numberStr = "\(currentText)"
                   sender.setTitle(numberStr, for: .normal)
               }
               else{
                   //last digit is 1, do nothing
                   print(currentText)
                   
               }

    }
    
    @IBAction func resetValues(_ sender: UIButton) {
        //retting the value to its original numbers
        buttonVal2.setTitle("2", for: .normal)
        buttonVal0.setTitle("0", for: .normal)
        buttonVal0_0.setTitle("0", for: .normal)
        buttonVal5.setTitle("5", for: .normal)
        buttonVal00_0.setTitle("0", for: .normal)
        buttonVal4.setTitle("4", for: .normal)
        buttonVal9.setTitle("9", for: .normal)
        buttonVal8.setTitle("8", for: .normal)
        buttonVal1.setTitle("1", for: .normal)
    }
    
}

